<?php
// Arquivo de rodapé simples para ser incluído nas views
// Se houver scripts JS ou fechamento de tags, eles iriam aqui.
?>
